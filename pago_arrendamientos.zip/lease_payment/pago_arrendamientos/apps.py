from django.apps import AppConfig


class PagoArrendamientosConfig(AppConfig):
    name = 'pago_arrendamientos'
